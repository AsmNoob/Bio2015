Instruction pour faire fonctionner les projet:

1) Extraire tout le dossier zip.
2) Ouvrir un terminal
3) Aller dans le dossier contenant le dossier extrait
4) Lancer la commande "python3 mini_projet_3.py"
	a) On vous propose tout d'abord de créer les profils des SH2 ou SH3 avec 2 outils différents.
	b) On vous propose d'afficher le profil selon les indices que vous désirez et de comparer le résultat au weblogo ouvert avec 5)
5) Pour comparer avec les weblogo il vous suffit d'ouvrir le "logo*.png" correspondant à votre choix et comparer avec les bornes choisies.

Si vous avez des question vis-à-vis de l'utilisation du programme envoyez un mail à cette adresse: gtionogu@ulb.ac.be
