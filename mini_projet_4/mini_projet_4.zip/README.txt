Instruction pour faire fonctionner les projet:

1) Extraire tout le dossier zip
2) entrez la commande "python3 mini_projet_4"
3) Tout le programme s'exécute, et termine avec l'affichage de Q3 et des MCC.

Si vous avez des question vis-à-vis de l'utilisation du programme envoyez un mail à cette adresse: gtionogu@ulb.ac.be
