Exemple d'utilisation du programme:

Welcome to the sequence aligner,
Introduce the following information to obtain the alignment between 2 sequences.
Enter the 1st sequence filename: data MP1 2015/Kinase-sequences.fasta
Choose 1 sequence from all given in the file ( from 0 to 4 ): 0
Same thing for the 2nd sequence,
Enter the 2nd sequence filename: data MP1 2015/Kinase-sequences.fasta
Choose 1 sequence from all given in the file ( from 0 to 4 ): 1
Enter the filename of the score matrix you want to use: ScoreMatrix/blosum62.txt
Enter the opening gap penalty: 5
Enter the extending gap penalty: 2
Give the alignmentType, 'global' or 'local': local
GCVQCKDKEATKLTEERDGSLNQSSGYRYGTDPTPQHYPSFGVTSIPNYNNFHAAGGQGLTVFGGVNSSSHTGTLRTRGGTGVTLFVALYDYEARTEDDLSFHKGEKFQILNSSEGDWWEARSLTTGETGYIPSNYVAPVDSIQAEEWYFGKLGRKDAERQLLSFGNPRGTFLIRESETTKGAYSLSIRDWDDMKGDHVKHYKIRKLDNGGYYITTRAQFETLQQLVQHYSERAAGLCCRLVVPCHKGMPRLTDLSVKTKDVWEIPRESLQLIKRLGNGQFGEVWMGTWNGNTKVAIKTLKPGTMSPESFLEEAQIMKKLKHDKLVQLYAVVSEEPIYIVTEYMNKGSLLDFLKDGEGRALKLPNLVDMAAQVAAGMAYIERMNYIHRDLRSANILVGNGLICKIADFGLARLIEDNEYTARQGAKFPIKWTAPEAALYGRFTIKSDVWSFGILLTELVTKGRVPYPGMNNREVLEQVERGYRMPCPQDCPISLHELMIHCWKKDPEERPTFEYLQSFLEDYFTATEPQYQPGENL
::::::::::::::.::::::.::::::::::::::::::::::::::::::::.:::::::::::::::::::::::::::::::.:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::.:.:::..:.:......:....:.   ::.::..:.::.:...::.:.:.:::.:::::::::::::::::::::::::::::::::::::::::::::::..:::::::::.:::::.:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::.::::::::::::::::.::
GCVQCKDKEATKLTDERDGSLTQSSGYRYGTDPTPQHYPSFGVTSIPNYNNFHATGGQGLTVFGGVNSSSHTGTLRTRGGTGVTLFEALYDYEARTEDDLSFHKGEKFQILNSSEGDWWEARSLTTGETGYIPSNYVAPVDSIQAEEWYFGKLGRKDAERQLLSFGNPRGTFLIRESETTKGAYSLSIRDWDDMKGDHVKHYKIRKLDNGGYYITTRAQFETLQQLVQHYSEKADGLCFNLTVIATNNTPQTVGLA---KDAWEVARDSLFLEQKLGQGCFAEVWRGTWNGNTKVAIKTLKPGTMSPESFLEEAQIMKKLKHDKLVQLYAVVSRRPIYIVTEYMSKGSLLIFLKDGEGRALKLPNLVDMAAQVAAGMAYIERMNYIHRDLRSANILVGNGLICKIADFGLARLIEDNEYTARQGAKFPIKWTAPEAALYGRFTIKSDVWSFGILLTELVTKGRVPYPGMNNREVLEQVERGYRMPCPQDCPISLHELMIHCWKKDPEERPTFEYLQGFLEDYFTATEPQYQPGDNL
92.4% identity
99.4% similarity
0.6% gap
Length : 536
Global score : 2633
